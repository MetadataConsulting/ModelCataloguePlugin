package org.modelcatalogue.core;

/**
 * Created by ladin on 17.02.14.
 */
public enum PublishedElementStatus {
    DRAFT, PENDING, FINALIZED, REMOVED
}
