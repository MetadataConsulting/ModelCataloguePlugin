package org.modelcatalogue.core.util.marshalling

import org.modelcatalogue.core.ConceptualDomain

class ConceptualDomainMarshaller extends CatalogueElementMarshallers {

    ConceptualDomainMarshaller() {
        super(ConceptualDomain)
    }
}




