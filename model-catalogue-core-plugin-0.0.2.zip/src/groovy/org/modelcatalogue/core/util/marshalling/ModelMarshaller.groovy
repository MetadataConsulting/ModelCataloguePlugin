package org.modelcatalogue.core.util.marshalling

import org.modelcatalogue.core.Model

class ModelMarshaller extends ExtendibleElementMarshallers {

    ModelMarshaller() {
        super(Model)
    }
}




