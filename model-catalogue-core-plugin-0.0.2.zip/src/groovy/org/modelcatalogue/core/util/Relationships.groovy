package org.modelcatalogue.core.util
/**
 * Wrapper used for easier marshalling of relations result lists
 */
class Relationships extends ListWrapper {
    String direction
}
