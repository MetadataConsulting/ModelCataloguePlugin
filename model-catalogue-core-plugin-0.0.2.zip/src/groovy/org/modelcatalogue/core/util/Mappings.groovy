package org.modelcatalogue.core.util

/**
 * Created by ladin on 25.02.14.
 */
class Mappings extends ListWrapper {

}
