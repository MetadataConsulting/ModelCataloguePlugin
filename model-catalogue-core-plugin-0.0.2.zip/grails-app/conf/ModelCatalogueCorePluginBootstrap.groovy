
class ModelCatalogueCorePluginBootstrap {

    def init = { servletContext ->

    }


    def destroy = {
    }
}