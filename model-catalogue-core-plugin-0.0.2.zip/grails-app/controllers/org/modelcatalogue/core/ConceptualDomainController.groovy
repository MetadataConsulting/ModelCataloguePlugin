package org.modelcatalogue.core

class ConceptualDomainController extends CatalogueElementController<ConceptualDomain> {

    ConceptualDomainController() {
        super(ConceptualDomain)
    }

}
