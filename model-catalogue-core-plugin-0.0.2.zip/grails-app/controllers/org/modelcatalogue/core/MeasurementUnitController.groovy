package org.modelcatalogue.core

class MeasurementUnitController extends CatalogueElementController<MeasurementUnit> {

    MeasurementUnitController() {
        super(MeasurementUnit)
    }


}
