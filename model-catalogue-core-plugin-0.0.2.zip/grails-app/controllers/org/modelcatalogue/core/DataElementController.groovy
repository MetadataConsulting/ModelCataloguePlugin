package org.modelcatalogue.core

class DataElementController extends CatalogueElementController<DataElement> {

    DataElementController() {
        super(DataElement)
    }

}
