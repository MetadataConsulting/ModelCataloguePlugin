package org.modelcatalogue.core

class ModelController extends CatalogueElementController<Model> {

    ModelController() {
        super(Model)
    }

}
