package org.modelcatalogue.core

class DataTypeController extends CatalogueElementController<DataType> {

    DataTypeController() {
        super(DataType)
    }

}
